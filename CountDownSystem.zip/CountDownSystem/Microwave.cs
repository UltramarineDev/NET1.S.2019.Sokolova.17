﻿using System;

namespace CountDownSystem
{
    class Microwave
    {
        public Microwave(CountDownTimer countDownTimer)
        {
            countDownTimer.NewTimeIsUp += DisplayMicrowaveMessage;           
        }

        private void DisplayMicrowaveMessage(object sender, TimesUpEventArgs e)
        {
            Console.WriteLine("Microvawe received: {0}", e.Message);
        }

        public void Unregister(CountDownTimer countDownTimer)
        {
            countDownTimer.NewTimeIsUp -= DisplayMicrowaveMessage;
        }

    }
}
