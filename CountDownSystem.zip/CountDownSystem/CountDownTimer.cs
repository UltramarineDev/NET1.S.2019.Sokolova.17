﻿using System;

namespace CountDownSystem
{
    public class CountDownTimer
    {
        public event EventHandler<TimesUpEventArgs> NewTimeIsUp = delegate { };

        private void TimerBegin(object sender, TimesUpEventArgs e)
        {
            NewTimeIsUp?.Invoke(this, e);
        }

        public void SimulateNewTimer(int timeWaitMilliseconds)
        {
            TimerBegin(this, new TimesUpEventArgs(timeWaitMilliseconds));
        }
    }
}
