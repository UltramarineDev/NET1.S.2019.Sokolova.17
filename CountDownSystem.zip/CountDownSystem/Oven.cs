﻿using System;

namespace CountDownSystem
{
    public class Oven
    {
        public Oven(CountDownTimer countDownTimer)
        {
            countDownTimer.NewTimeIsUp += DisplayOvenMessage;
        }

        private void DisplayOvenMessage(object sender, TimesUpEventArgs e)
        {
            Console.WriteLine("Oven received: {0}", e.Message);
        }

        public void Unregister(CountDownTimer countDownTimer)
        {
            countDownTimer.NewTimeIsUp -= DisplayOvenMessage;
        }
    }
}
